class Plateau
    def initialize(plateau)
        @plateau = plateau.split('')
    end 
end
